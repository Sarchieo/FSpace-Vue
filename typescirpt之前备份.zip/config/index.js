export const iceGridInstanceName = "DemoIceGrid";
// export const serverIp = "114.116.149.145" // 华为云 1
// export const serverIp = "114.116.155.221" // 华为云 2
// export const serverIp = "114.116.137.5"
// export const serverIp = "192.168.1.152";// 蒋老师
// export const serverIp = "192.168.1.110";
// export const serverIp = "192.168.1.145";// 李世平
export const serverIp = "192.168.1.34"; // 惠哥
// export const serverIp = "192.168.1.119";
export const serverPort = 4062;

const CALLBACK_ACTION = {
  READY: 1,
  COMPLETE: 2,
  ERROR: 3
};

export { CALLBACK_ACTION }

