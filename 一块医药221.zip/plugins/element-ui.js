import Vue from 'vue'
import {Cascader, DatePicker} from 'element-ui'
Vue.use(Cascader, DatePicker)