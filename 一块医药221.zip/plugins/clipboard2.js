import VueClipboard from 'vue-clipboard2'
import Vue from 'vue'
Vue.use(VueClipboard)  //必须这样子引用 否则会报错的