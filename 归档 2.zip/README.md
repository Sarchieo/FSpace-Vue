# 项目介绍

NUXT服务端渲染测试。

### 安装

```
npm install
```

And 

```
yarn
```

## 运行

```
npm run dev
```

