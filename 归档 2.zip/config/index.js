export const iceGridInstanceName = "DemoIceGrid";
export const serverIp = "114.116.149.145";
// export const serverIp = "192.168.1.152";
// export const serverIp = "192.168.1.110";
export const serverPort = 4062;

const CALLBACK_ACTION = {
  READY: 1,
  COMPLETE: 2,
  ERROR: 3
};

export { CALLBACK_ACTION }

