export default {
  user: {},
  areas: {},
  userStatus: false,
  keyword: ''
}