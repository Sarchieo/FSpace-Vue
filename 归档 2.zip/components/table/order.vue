<template>
  <div class="order">
    <slot name="tabledata"></slot>
  </div>
</template>
<script>
export default {
     name: 'f-space-order',
    data() {

    }
}
</script>
<style lang="less" scoped>
    
</style>