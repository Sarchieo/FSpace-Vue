import Vue from 'vue'
import {Cascader, DatePicker, Upload} from 'element-ui'
Vue.use(Cascader, DatePicker, Upload)