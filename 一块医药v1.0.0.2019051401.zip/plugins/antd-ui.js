import Vue from 'vue'
import Antd from 'ant-design-vue/lib'

export default () => {
  Vue.use(Antd)
}
