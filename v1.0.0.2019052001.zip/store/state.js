export default {
  user: {},
  areas: {},
  userStatus: false,
  keyword: '',
  selectedKeys: '',
  isNewNotice: false,
  noticeList: []
}